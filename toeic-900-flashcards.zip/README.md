# TOEIC 900 Flashcards

GitHub Pages に置くだけで動く、単一 HTML のフラッシュカードアプリです。

## 公開手順
1. GitHub で新規リポジトリ **toeic-900-flashcards** を作成（Public）。
2. この `index.html` と `README.md` をアップロード。
3. **Settings → Pages** → `Deploy from a branch` / `main` / `/ (root)` → **Save**。
4. `https://<username>.github.io/toeic-900-flashcards/` で利用可能。

## 注意（iPhone）
ファイルAppのプレビュー（Quick Look）ではJavaScriptが動きません。必ず **Safari** で開いてください。
